package hotel.ui;

import hotel.exception.HotelException;
import hotel.extras.Booking;
import hotel.model.Notification;
import hotel.model.Payment;
import hotel.model.Reservation;
import hotel.model.ReservationStatus;
import hotel.model.Role;
import hotel.model.Room;
import hotel.model.RoomType;
import hotel.model.User;
import hotel.pricing.PricingStrategy;
import hotel.service.AuthService;
import hotel.service.NotificationService;
import hotel.service.PaymentService;
import hotel.service.PricingService;
import hotel.service.ReservationService;
import hotel.service.RoomService;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ConsoleApp {
    private final Scanner in = new Scanner(System.in);
    private final AuthService auth;
    private final RoomService roomService;
    private final ReservationService reservationService;
    private final PaymentService paymentService;
    private final PricingService pricingService;
    private final NotificationService notificationService;

    public ConsoleApp(AuthService auth, RoomService roomService, ReservationService reservationService,
                      PaymentService paymentService, PricingService pricingService,
                      NotificationService notificationService) {
        this.auth = auth;
        this.roomService = roomService;
        this.reservationService = reservationService;
        this.paymentService = paymentService;
        this.pricingService = pricingService;
        this.notificationService = notificationService;
    }

    public void start() {
        System.out.println("===== HOTEL RESERVATION SYSTEM =====  (today: " + LocalDate.now() + ")");
        while (true) {
            System.out.println("\n--- Main menu ---");
            System.out.println("1. Log in");
            System.out.println("2. Register");
            System.out.println("3. View rooms");
            System.out.println("0. Exit");
            int choice = readInt("> ", 0, 3);
            if (choice == 0) {
                System.out.println("Goodbye!");
                return;
            }
            try {
                if (choice == 1) {
                    login();
                } else if (choice == 2) {
                    register();
                } else {
                    showRooms();
                }
            } catch (HotelException e) {
                System.out.println("[!] " + e.getMessage());
            }
        }
    }

    private void login() {
        String username = readText("Username: ");
        String password = readText("Password: ");
        User user = auth.login(username, password);
        System.out.println("Welcome, " + user.getFullName() + "!");
        if (user.getRole() == Role.ADMIN) {
            adminMenu(user);
        } else {
            customerMenu(user);
        }
    }

    private void register() {
        String username = readText("Username: ");
        String password = readText("Password (min 6 characters): ");
        String fullName = readText("Full name: ");
        String phone = readText("Phone (+77011234567): ");
        auth.register(username, password, fullName, phone);
        System.out.println("Account created. Now you can log in.");
    }

    private void customerMenu(User user) {
        while (true) {
            System.out.println("\n--- Customer menu ---");
            System.out.println("1. Find free rooms");
            System.out.println("2. Make a reservation");
            System.out.println("3. My reservations");
            System.out.println("4. Pay for a reservation");
            System.out.println("5. Cancel a reservation");
            System.out.println("6. My notifications");
            System.out.println("0. Log out");
            int choice = readInt("> ", 0, 6);
            if (choice == 0) {
                return;
            }
            try {
                switch (choice) {
                    case 1 -> findRooms();
                    case 2 -> makeReservation(user);
                    case 3 -> printReservations(reservationService.getForCustomer(user));
                    case 4 -> pay(user);
                    case 5 -> cancel(user);
                    case 6 -> showNotifications(user);
                }
            } catch (HotelException e) {
                System.out.println("[!] " + e.getMessage());
            }
        }
    }

    private void findRooms() {
        LocalDate checkIn = readDate("Check-in date (YYYY-MM-DD): ");
        LocalDate checkOut = readDate("Check-out date (YYYY-MM-DD): ");
        int guests = readInt("Guests: ", 1, 10);
        List<Room> rooms = roomService.findFreeRooms(checkIn, checkOut, guests);
        if (rooms.isEmpty()) {
            System.out.println("No free rooms for these dates.");
            return;
        }
        System.out.println("Free rooms (pricing: " + pricingService.getCurrent().getName() + "):");
        for (Room room : rooms) {
            System.out.println("  Room " + room.getNumber() + "  " + room.getType() + "  up to " + room.getCapacity()
                    + " guests  -> " + pricingService.calculatePrice(room, checkIn, checkOut) + " KZT for the stay");
        }
    }

    private void makeReservation(User user) {
        LocalDate checkIn = readDate("Check-in date (YYYY-MM-DD): ");
        LocalDate checkOut = readDate("Check-out date (YYYY-MM-DD): ");
        int guests = readInt("Guests: ", 1, 10);
        String roomNumber = readText("Room number: ");
        Room room = roomService.getRoom(roomNumber);

        List<String> extras = new ArrayList<>();
        if (readYesNo("Add breakfast (5,000 KZT per night)?")) {
            extras.add("BREAKFAST");
        }
        if (readYesNo("Add airport transfer (12,000 KZT)?")) {
            extras.add("TRANSFER");
        }
        if (readYesNo("Add late check-out (8,000 KZT)?")) {
            extras.add("LATE_CHECKOUT");
        }

        Booking booking = reservationService.buildBooking(room, checkIn, checkOut, extras);
        System.out.println("Your booking: " + booking.getDescription());
        System.out.println("Total price: " + booking.getPrice() + " KZT");
        if (!readYesNo("Confirm?")) {
            System.out.println("Cancelled.");
            return;
        }
        Reservation reservation = reservationService.create(user, roomNumber, checkIn, checkOut, guests, extras);
        System.out.println("Reservation #" + reservation.getId() + " created. Status: " + reservation.getStatus());
        if (readYesNo("Pay now?")) {
            payReservation(user, reservation.getId());
        }
    }

    private void pay(User user) {
        int id = readInt("Reservation id: ", 1, Integer.MAX_VALUE);
        payReservation(user, id);
    }

    private void payReservation(User user, int reservationId) {
        System.out.println("(test card: 4242 4242 4242 4242, no money: 4000 0000 0000 0002)");
        String card = readText("Card number: ");
        String expiry = readText("Expiry (MM/YY): ");
        String cvv = readText("CVV: ");
        paymentService.pay(user, reservationId, card, expiry, cvv);
        System.out.println("Payment successful! Reservation #" + reservationId + " is CONFIRMED.");
    }

    private void cancel(User user) {
        int id = readInt("Reservation id: ", 1, Integer.MAX_VALUE);
        reservationService.cancel(user, id);
        System.out.println("Reservation #" + id + " cancelled.");
    }

    private void showNotifications(User user) {
        List<Notification> list = notificationService.getFor(user.getId());
        if (list.isEmpty()) {
            System.out.println("No notifications.");
        }
        for (Notification n : list) {
            System.out.println("  [" + n.getDate().toString().replace('T', ' ') + "] " + n.getMessage());
        }
    }

    private void adminMenu(User admin) {
        while (true) {
            System.out.println("\n--- Admin menu ---");
            System.out.println("1. View rooms");
            System.out.println("2. Add a room");
            System.out.println("3. Change room price");
            System.out.println("4. All reservations");
            System.out.println("5. Check in");
            System.out.println("6. Check out");
            System.out.println("7. Cancel a reservation");
            System.out.println("8. Pricing strategy (now: " + pricingService.getCurrent().getName() + ")");
            System.out.println("9. Payments");
            System.out.println("0. Log out");
            int choice = readInt("> ", 0, 9);
            if (choice == 0) {
                return;
            }
            try {
                switch (choice) {
                    case 1 -> showRooms();
                    case 2 -> addRoom();
                    case 3 -> roomService.changePrice(readText("Room number: "), readInt("New price: ", 1, 10_000_000));
                    case 4 -> printReservations(reservationService.getAll());
                    case 5 -> reservationService.checkIn(readInt("Reservation id: ", 1, Integer.MAX_VALUE));
                    case 6 -> reservationService.checkOut(readInt("Reservation id: ", 1, Integer.MAX_VALUE));
                    case 7 -> cancel(admin);
                    case 8 -> chooseStrategy();
                    case 9 -> showPayments();
                }
                if (choice == 3 || choice == 5 || choice == 6) {
                    System.out.println("Done.");
                }
            } catch (HotelException e) {
                System.out.println("[!] " + e.getMessage());
            }
        }
    }

    private void addRoom() {
        String number = readText("Room number (3 digits): ");
        RoomType[] types = RoomType.values();
        for (int i = 0; i < types.length; i++) {
            System.out.println("  " + (i + 1) + ". " + types[i]);
        }
        RoomType type = types[readInt("Type: ", 1, types.length) - 1];
        int capacity = readInt("Capacity: ", 1, 10);
        long price = readInt("Price per night (KZT): ", 1, 10_000_000);
        roomService.addRoom(number, type, capacity, price);
        System.out.println("Room " + number + " added.");
    }

    private void chooseStrategy() {
        List<PricingStrategy> strategies = pricingService.getStrategies();
        for (int i = 0; i < strategies.size(); i++) {
            System.out.println("  " + (i + 1) + ". " + strategies.get(i).getName());
        }
        PricingStrategy chosen = strategies.get(readInt("Choose: ", 1, strategies.size()) - 1);
        pricingService.setCurrent(chosen);
        System.out.println("Now using: " + chosen.getName());
    }

    private void showPayments() {
        for (Payment p : paymentService.getAll()) {
            System.out.println("  #" + p.getId() + " reservation #" + p.getReservationId() + "  " + p.getAmount()
                    + " KZT  " + (p.isSuccessful() ? "OK " + p.getTransactionId() : "FAILED") + "  " + p.getMessage());
        }
    }


    private void showRooms() {
        for (Room room : roomService.getAllRooms()) {
            System.out.println("  Room " + room.getNumber() + "  " + room.getType() + "  up to " + room.getCapacity()
                    + " guests  " + room.getPricePerNight() + " KZT/night");
        }
    }

    private void printReservations(List<Reservation> list) {
        if (list.isEmpty()) {
            System.out.println("No reservations.");
        }
        for (Reservation r : list) {
            System.out.println("  #" + r.getId() + "  " + r.getDescription() + "  " + r.getCheckIn() + " -> "
                    + r.getCheckOut() + "  " + r.getTotalPrice() + " KZT  " + r.getStatus());
        }
    }

    private String readText(String prompt) {
        System.out.print(prompt);
        if (!in.hasNextLine()) {
            System.exit(0);
        }
        return in.nextLine().trim();
    }

    private int readInt(String prompt, int min, int max) {
        while (true) {
            String text = readText(prompt);
            try {
                int value = Integer.parseInt(text);
                if (value >= min && value <= max) {
                    return value;
                }
            } catch (NumberFormatException ignored) {

            }
            System.out.println("[!] Enter a number from " + min + " to " + max + ".");
        }
    }

    private LocalDate readDate(String prompt) {
        while (true) {
            try {
                return LocalDate.parse(readText(prompt));
            } catch (DateTimeParseException e) {
                System.out.println("[!] Use the format YYYY-MM-DD, for example 2026-12-20.");
            }
        }
    }

    private boolean readYesNo(String prompt) {
        while (true) {
            String answer = readText(prompt + " (y/n): ").toLowerCase();
            if (answer.equals("y")) {
                return true;
            }
            if (answer.equals("n")) {
                return false;
            }
            System.out.println("[!] Type y or n.");
        }
    }
}
