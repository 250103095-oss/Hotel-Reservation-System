package hotel.model;

public enum RoomType {
    STANDARD, DELUXE, FAMILY, SUITE
}
