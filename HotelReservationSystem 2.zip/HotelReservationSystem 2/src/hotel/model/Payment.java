package hotel.model;

import java.time.LocalDateTime;

public class Payment {
    private int id;
    private final int reservationId;
    private final long amount;
    private final boolean successful;
    private final String transactionId;
    private final String message;
    private final LocalDateTime date;

    public Payment(int id, int reservationId, long amount, boolean successful, String transactionId,
                   String message, LocalDateTime date) {
        this.id = id;
        this.reservationId = reservationId;
        this.amount = amount;
        this.successful = successful;
        this.transactionId = transactionId;
        this.message = message;
        this.date = date;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public int getReservationId() { return reservationId; }
    public long getAmount() { return amount; }
    public boolean isSuccessful() { return successful; }
    public String getTransactionId() { return transactionId; }
    public String getMessage() { return message; }
    public LocalDateTime getDate() { return date; }
}
