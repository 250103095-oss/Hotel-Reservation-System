package hotel.model;

public enum ReservationStatus {
    PENDING_PAYMENT, CONFIRMED, CHECKED_IN, CHECKED_OUT, CANCELLED
}
