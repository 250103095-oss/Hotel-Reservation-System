package hotel.model;

import hotel.exception.HotelException;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class Reservation {
    private int id;
    private final int customerId;
    private final String roomNumber;
    private final LocalDate checkIn;
    private final LocalDate checkOut;
    private final int guests;
    private final String extras;
    private final long totalPrice;
    private final String description;
    private ReservationStatus status;

    public Reservation(int id, int customerId, String roomNumber, LocalDate checkIn, LocalDate checkOut,
                       int guests, String extras, long totalPrice, String description, ReservationStatus status) {
        this.id = id;
        this.customerId = customerId;
        this.roomNumber = roomNumber;
        this.checkIn = checkIn;
        this.checkOut = checkOut;
        this.guests = guests;
        this.extras = extras;
        this.totalPrice = totalPrice;
        this.description = description;
        this.status = status;
    }

    public int nights() {
        return (int) ChronoUnit.DAYS.between(checkIn, checkOut);
    }

    public boolean overlaps(LocalDate otherIn, LocalDate otherOut) {
        boolean active = status != ReservationStatus.CANCELLED && status != ReservationStatus.CHECKED_OUT;
        return active && checkIn.isBefore(otherOut) && otherIn.isBefore(checkOut);
    }


    public void confirm() {
        if (status != ReservationStatus.PENDING_PAYMENT) {
            throw new HotelException("Reservation #" + id + " is already paid or closed.");
        }
        status = ReservationStatus.CONFIRMED;
    }

    public void checkIn(LocalDate today) {
        if (status != ReservationStatus.CONFIRMED) {
            throw new HotelException("Only paid (CONFIRMED) reservations can check in. Status: " + status);
        }
        if (today.isBefore(checkIn)) {
            throw new HotelException("Check-in is possible from " + checkIn + ".");
        }
        status = ReservationStatus.CHECKED_IN;
    }

    public void checkOut() {
        if (status != ReservationStatus.CHECKED_IN) {
            throw new HotelException("Guest is not checked in. Status: " + status);
        }
        status = ReservationStatus.CHECKED_OUT;
    }

    public void cancel() {
        if (status != ReservationStatus.PENDING_PAYMENT && status != ReservationStatus.CONFIRMED) {
            throw new HotelException("Reservation #" + id + " cannot be cancelled. Status: " + status);
        }
        status = ReservationStatus.CANCELLED;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public int getCustomerId() { return customerId; }
    public String getRoomNumber() { return roomNumber; }
    public LocalDate getCheckIn() { return checkIn; }
    public LocalDate getCheckOut() { return checkOut; }
    public int getGuests() { return guests; }
    public String getExtras() { return extras; }
    public long getTotalPrice() { return totalPrice; }
    public String getDescription() { return description; }
    public ReservationStatus getStatus() { return status; }
}
