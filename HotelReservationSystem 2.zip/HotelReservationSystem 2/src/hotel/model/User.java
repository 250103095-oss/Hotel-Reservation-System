package hotel.model;

public class User {
    private int id;
    private final String username;
    private final String passwordHash;
    private final String fullName;
    private final String phone;
    private final Role role;

    public User(int id, String username, String passwordHash, String fullName, String phone, Role role) {
        this.id = id;
        this.username = username;
        this.passwordHash = passwordHash;
        this.fullName = fullName;
        this.phone = phone;
        this.role = role;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getUsername() { return username; }
    public String getPasswordHash() { return passwordHash; }
    public String getFullName() { return fullName; }
    public String getPhone() { return phone; }
    public Role getRole() { return role; }
}
