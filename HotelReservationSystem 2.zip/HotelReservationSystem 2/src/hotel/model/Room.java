package hotel.model;

public class Room {
    private int id;
    private final String number;
    private final RoomType type;
    private final int capacity;
    private long pricePerNight;

    public Room(int id, String number, RoomType type, int capacity, long pricePerNight) {
        this.id = id;
        this.number = number;
        this.type = type;
        this.capacity = capacity;
        this.pricePerNight = pricePerNight;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getNumber() { return number; }
    public RoomType getType() { return type; }
    public int getCapacity() { return capacity; }
    public long getPricePerNight() { return pricePerNight; }
    public void setPricePerNight(long pricePerNight) { this.pricePerNight = pricePerNight; }
}
