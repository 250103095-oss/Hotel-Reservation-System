package hotel.model;

public enum Role {
    ADMIN, CUSTOMER
}
