package hotel.model;

import java.time.LocalDateTime;

public class Notification {
    private int id;
    private final int userId;
    private final String message;
    private final LocalDateTime date;

    public Notification(int id, int userId, String message, LocalDateTime date) {
        this.id = id;
        this.userId = userId;
        this.message = message;
        this.date = date;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public int getUserId() { return userId; }
    public String getMessage() { return message; }
    public LocalDateTime getDate() { return date; }
}
