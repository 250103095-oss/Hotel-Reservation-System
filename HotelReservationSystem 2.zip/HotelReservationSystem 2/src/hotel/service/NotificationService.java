package hotel.service;

import hotel.model.Notification;
import hotel.repository.NotificationRepository;

import java.time.LocalDateTime;
import java.util.List;

public class NotificationService {
    private final NotificationRepository notifications;

    public NotificationService(NotificationRepository notifications) {
        this.notifications = notifications;
    }

    public void send(int userId, String message) {
        notifications.save(new Notification(0, userId, message, LocalDateTime.now().withNano(0)));
    }

    public List<Notification> getFor(int userId) {
        return notifications.findByUser(userId);
    }
}
