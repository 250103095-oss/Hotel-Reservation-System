package hotel.service;

import hotel.exception.HotelException;
import hotel.exception.ValidationException;
import hotel.model.Role;
import hotel.model.User;
import hotel.repository.UserRepository;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HexFormat;

public class AuthService {
    private final UserRepository users;

    public AuthService(UserRepository users) {
        this.users = users;
    }

    public User register(String username, String password, String fullName, String phone) {
        Validator.username(username);
        Validator.password(password);
        Validator.notEmpty(fullName, "Full name");
        Validator.phone(phone);
        if (users.findByUsername(username) != null) {
            throw new ValidationException("Username '" + username + "' is already taken.");
        }
        return users.save(new User(0, username, hash(password), fullName, phone, Role.CUSTOMER));
    }

    public User login(String username, String password) {
        User user = users.findByUsername(username);
        if (user == null || !user.getPasswordHash().equals(hash(password))) {
            throw new HotelException("Wrong username or password.");
        }
        return user;
    }

    public static String hash(String password) {
        try {
            byte[] bytes = MessageDigest.getInstance("SHA-256").digest(password.getBytes(StandardCharsets.UTF_8));
            return HexFormat.of().formatHex(bytes);
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
    }
}
