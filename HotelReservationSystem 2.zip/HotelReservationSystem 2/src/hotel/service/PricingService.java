package hotel.service;

import hotel.model.Room;
import hotel.pricing.PricingStrategy;

import java.time.LocalDate;
import java.util.List;

public class PricingService {
    private final List<PricingStrategy> strategies;
    private PricingStrategy current;

    public PricingService(List<PricingStrategy> strategies) {
        this.strategies = strategies;
        this.current = strategies.get(0);
    }

    public List<PricingStrategy> getStrategies() {
        return strategies;
    }

    public PricingStrategy getCurrent() {
        return current;
    }

    public void setCurrent(PricingStrategy strategy) {
        this.current = strategy;
    }

    public long calculatePrice(Room room, LocalDate checkIn, LocalDate checkOut) {
        return current.calculatePrice(room, checkIn, checkOut);
    }
}
