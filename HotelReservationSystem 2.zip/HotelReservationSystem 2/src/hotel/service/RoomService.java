package hotel.service;

import hotel.exception.NotFoundException;
import hotel.exception.ValidationException;
import hotel.model.Reservation;
import hotel.model.Room;
import hotel.model.RoomType;
import hotel.repository.ReservationRepository;
import hotel.repository.RoomRepository;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class RoomService {
    private final RoomRepository rooms;
    private final ReservationRepository reservations;

    public RoomService(RoomRepository rooms, ReservationRepository reservations) {
        this.rooms = rooms;
        this.reservations = reservations;
    }

    public List<Room> getAllRooms() {
        return rooms.findAll();
    }

    public Room getRoom(String number) {
        Room room = rooms.findByNumber(number);
        if (room == null) {
            throw new NotFoundException("Room " + number + " does not exist.");
        }
        return room;
    }

    public boolean isFree(String roomNumber, LocalDate checkIn, LocalDate checkOut) {
        for (Reservation r : reservations.findByRoom(roomNumber)) {
            if (r.overlaps(checkIn, checkOut)) {
                return false;
            }
        }
        return true;
    }

    public List<Room> findFreeRooms(LocalDate checkIn, LocalDate checkOut, int guests) {
        Validator.dates(checkIn, checkOut);
        List<Room> result = new ArrayList<>();
        for (Room room : rooms.findAll()) {
            if (room.getCapacity() >= guests && isFree(room.getNumber(), checkIn, checkOut)) {
                result.add(room);
            }
        }
        return result;
    }

    public Room addRoom(String number, RoomType type, int capacity, long price) {
        if (number == null || !number.matches("\\d{3}")) {
            throw new ValidationException("Room number must have 3 digits, for example 105.");
        }
        if (rooms.findByNumber(number) != null) {
            throw new ValidationException("Room " + number + " already exists.");
        }
        Validator.positive(capacity, "Capacity");
        Validator.positive(price, "Price");
        return rooms.save(new Room(0, number, type, capacity, price));
    }

    public void changePrice(String number, long newPrice) {
        Validator.positive(newPrice, "Price");
        Room room = getRoom(number);
        room.setPricePerNight(newPrice);
        rooms.save(room);
    }
}
