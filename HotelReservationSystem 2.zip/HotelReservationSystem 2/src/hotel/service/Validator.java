package hotel.service;

import hotel.exception.ValidationException;

import java.time.LocalDate;

public class Validator {

    public static void notEmpty(String value, String field) {
        if (value == null || value.isBlank()) {
            throw new ValidationException(field + " must not be empty.");
        }
    }

    public static void username(String value) {
        if (value == null || !value.matches("[A-Za-z0-9_]{3,20}")) {
            throw new ValidationException("Username must be 3-20 letters or digits.");
        }
    }

    public static void password(String value) {
        if (value == null || value.length() < 6) {
            throw new ValidationException("Password must be at least 6 characters.");
        }
    }

    public static void phone(String value) {
        if (value == null || !value.matches("\\+?\\d{10,15}")) {
            throw new ValidationException("Phone must have 10-15 digits, for example +77011234567.");
        }
    }

    public static void dates(LocalDate checkIn, LocalDate checkOut) {
        if (checkIn.isBefore(LocalDate.now())) {
            throw new ValidationException("Check-in date cannot be in the past.");
        }
        if (!checkOut.isAfter(checkIn)) {
            throw new ValidationException("Check-out date must be after check-in date.");
        }
    }

    public static void positive(long value, String field) {
        if (value <= 0) {
            throw new ValidationException(field + " must be greater than 0.");
        }
    }
}
