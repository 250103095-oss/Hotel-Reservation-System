package hotel.service;

import hotel.exception.HotelException;
import hotel.exception.NotFoundException;
import hotel.exception.ValidationException;
import hotel.extras.AirportTransferDecorator;
import hotel.extras.BasicBooking;
import hotel.extras.Booking;
import hotel.extras.BreakfastDecorator;
import hotel.extras.LateCheckoutDecorator;
import hotel.model.Reservation;
import hotel.model.ReservationStatus;
import hotel.model.Role;
import hotel.model.Room;
import hotel.model.User;
import hotel.repository.ReservationRepository;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

public class ReservationService {
    private final ReservationRepository reservations;
    private final RoomService roomService;
    private final PricingService pricingService;
    private final NotificationService notifications;

    public ReservationService(ReservationRepository reservations, RoomService roomService,
                              PricingService pricingService, NotificationService notifications) {
        this.reservations = reservations;
        this.roomService = roomService;
        this.pricingService = pricingService;
        this.notifications = notifications;
    }

    public Booking buildBooking(Room room, LocalDate checkIn, LocalDate checkOut, List<String> extras) {
        int nights = (int) ChronoUnit.DAYS.between(checkIn, checkOut);
        long roomPrice = pricingService.calculatePrice(room, checkIn, checkOut);
        Booking booking = new BasicBooking(room.getNumber(), nights, roomPrice);
        for (String extra : extras) {
            switch (extra) {
                case "BREAKFAST" -> booking = new BreakfastDecorator(booking);
                case "TRANSFER" -> booking = new AirportTransferDecorator(booking);
                case "LATE_CHECKOUT" -> booking = new LateCheckoutDecorator(booking);
                default -> throw new ValidationException("Unknown extra service: " + extra);
            }
        }
        return booking;
    }

    public Reservation create(User customer, String roomNumber, LocalDate checkIn, LocalDate checkOut,
                              int guests, List<String> extras) {
        Validator.dates(checkIn, checkOut);
        Room room = roomService.getRoom(roomNumber);
        if (guests < 1 || guests > room.getCapacity()) {
            throw new ValidationException("Room " + roomNumber + " is for 1-" + room.getCapacity() + " guests.");
        }
        if (!roomService.isFree(roomNumber, checkIn, checkOut)) {
            throw new HotelException("Room " + roomNumber + " is already booked for these dates.");
        }
        Booking booking = buildBooking(room, checkIn, checkOut, extras);
        Reservation reservation = new Reservation(0, customer.getId(), roomNumber, checkIn, checkOut, guests,
                String.join(",", extras), booking.getPrice(), booking.getDescription(),
                ReservationStatus.PENDING_PAYMENT);
        reservations.save(reservation);
        notifications.send(customer.getId(), "Reservation #" + reservation.getId() + " created: "
                + booking.getDescription() + ". Total " + booking.getPrice() + " KZT. Please pay to confirm.");
        return reservation;
    }

    public Reservation get(int id) {
        Reservation reservation = reservations.findById(id);
        if (reservation == null) {
            throw new NotFoundException("Reservation #" + id + " does not exist.");
        }
        return reservation;
    }

    public List<Reservation> getForCustomer(User customer) {
        return reservations.findByCustomer(customer.getId());
    }

    public List<Reservation> getAll() {
        return reservations.findAll();
    }

    public void cancel(User user, int id) {
        Reservation reservation = get(id);
        if (user.getRole() != Role.ADMIN && reservation.getCustomerId() != user.getId()) {
            throw new HotelException("You can cancel only your own reservations.");
        }
        reservation.cancel();
        reservations.save(reservation);
        notifications.send(reservation.getCustomerId(), "Reservation #" + id + " was cancelled.");
    }

    public void checkIn(int id) {
        Reservation reservation = get(id);
        reservation.checkIn(LocalDate.now());
        reservations.save(reservation);
        notifications.send(reservation.getCustomerId(), "Welcome! You are checked in (reservation #" + id + ").");
    }

    public void checkOut(int id) {
        Reservation reservation = get(id);
        reservation.checkOut();
        reservations.save(reservation);
        notifications.send(reservation.getCustomerId(), "You are checked out (reservation #" + id + "). Thank you!");
    }

    void confirm(Reservation reservation) {
        reservation.confirm();
        reservations.save(reservation);
    }
}
