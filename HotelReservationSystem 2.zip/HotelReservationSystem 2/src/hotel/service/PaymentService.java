package hotel.service;

import hotel.exception.HotelException;
import hotel.exception.PaymentException;
import hotel.model.Payment;
import hotel.model.Reservation;
import hotel.model.ReservationStatus;
import hotel.model.User;
import hotel.payment.PaymentProcessor;
import hotel.payment.PaymentResult;
import hotel.repository.PaymentRepository;

import java.time.LocalDateTime;
import java.util.List;

public class PaymentService {
    private final PaymentProcessor processor;
    private final PaymentRepository payments;
    private final ReservationService reservationService;
    private final NotificationService notifications;

    public PaymentService(PaymentProcessor processor, PaymentRepository payments,
                          ReservationService reservationService, NotificationService notifications) {
        this.processor = processor;
        this.payments = payments;
        this.reservationService = reservationService;
        this.notifications = notifications;
    }

    public void pay(User customer, int reservationId, String cardNumber, String expiry, String cvv) {
        Reservation reservation = reservationService.get(reservationId);
        if (reservation.getCustomerId() != customer.getId()) {
            throw new HotelException("You can pay only for your own reservations.");
        }
        if (reservation.getStatus() != ReservationStatus.PENDING_PAYMENT) {
            throw new HotelException("Reservation #" + reservationId + " does not need payment.");
        }
        PaymentResult result = processor.pay(reservation.getTotalPrice(), cardNumber, expiry, cvv);
        payments.save(new Payment(0, reservationId, reservation.getTotalPrice(), result.isSuccessful(),
                result.getTransactionId(), result.getMessage(), LocalDateTime.now().withNano(0)));
        if (!result.isSuccessful()) {
            throw new PaymentException("Payment declined: " + result.getMessage());
        }
        reservationService.confirm(reservation);
        notifications.send(customer.getId(), "Reservation #" + reservationId + " is CONFIRMED. Paid "
                + reservation.getTotalPrice() + " KZT.");
    }

    public List<Payment> getAll() {
        return payments.findAll();
    }
}
