package hotel.payment;

public class QuickPayAdapter implements PaymentProcessor {
    private final QuickPayClient quickPay;

    public QuickPayAdapter(QuickPayClient quickPay) {
        this.quickPay = quickPay;
    }

    @Override
    public PaymentResult pay(long amountKzt, String cardNumber, String expiry, String cvv) {
        if (expiry == null || !expiry.matches("(0[1-9]|1[0-2])/\\d{2}")) {
            return new PaymentResult(false, "", "Expiry date must be in MM/YY format.");
        }
        int month = Integer.parseInt(expiry.substring(0, 2));
        int year = 2000 + Integer.parseInt(expiry.substring(3));
        String digits = cardNumber == null ? "" : cardNumber.replace(" ", "");
        long amountInTiyn = amountKzt * 100;

        int code = quickPay.makePayment(digits, month, year, cvv, amountInTiyn);

        switch (code) {
            case 0:
                return new PaymentResult(true, quickPay.getLastTransactionId(), "Payment approved.");
            case 51:
                return new PaymentResult(false, "", "Insufficient funds on the card.");
            case 54:
                return new PaymentResult(false, "", "The card has expired.");
            default:
                return new PaymentResult(false, "", "Card details are invalid.");
        }
    }
}
