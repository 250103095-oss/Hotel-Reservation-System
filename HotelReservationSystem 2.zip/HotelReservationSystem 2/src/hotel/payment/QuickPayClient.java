package hotel.payment;

import java.time.YearMonth;

public class QuickPayClient {
    private int counter = 1000;
    private String lastTransactionId;

    public int makePayment(String cardNumber, int expMonth, int expYear, String cvv, long amountInTiyn) {
        if (cardNumber == null || !cardNumber.matches("\\d{16}") || cvv == null || !cvv.matches("\\d{3}")
                || expMonth < 1 || expMonth > 12 || amountInTiyn <= 0) {
            return 14;
        }
        if (YearMonth.of(expYear, expMonth).isBefore(YearMonth.now())) {
            return 54;
        }
        if (cardNumber.endsWith("0002")) {
            return 51;
        }
        counter++;
        lastTransactionId = "QP-" + System.currentTimeMillis() % 100000 + counter;
        return 0;
    }

    public String getLastTransactionId() {
        return lastTransactionId;
    }
}
