package hotel.payment;

public interface PaymentProcessor {
    PaymentResult pay(long amountKzt, String cardNumber, String expiry, String cvv);
}
