package hotel.exception;

public class PaymentException extends HotelException {
    public PaymentException(String message) {
        super(message);
    }
}
