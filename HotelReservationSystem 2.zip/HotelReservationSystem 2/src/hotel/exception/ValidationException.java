package hotel.exception;

public class ValidationException extends HotelException {
    public ValidationException(String message) {
        super(message);
    }
}
