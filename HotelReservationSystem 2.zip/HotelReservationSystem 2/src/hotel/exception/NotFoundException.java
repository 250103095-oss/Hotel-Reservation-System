package hotel.exception;

public class NotFoundException extends HotelException {
    public NotFoundException(String message) {
        super(message);
    }
}
