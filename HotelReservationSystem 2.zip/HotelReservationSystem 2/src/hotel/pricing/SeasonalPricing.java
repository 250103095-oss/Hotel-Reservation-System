package hotel.pricing;

import hotel.model.Room;

import java.time.LocalDate;
import java.time.Month;

public class SeasonalPricing implements PricingStrategy {

    @Override
    public String getName() {
        return "Seasonal (Jun-Aug, Dec +25%; Nov -15%)";
    }

    @Override
    public long calculatePrice(Room room, LocalDate checkIn, LocalDate checkOut) {
        long total = 0;
        for (LocalDate night = checkIn; night.isBefore(checkOut); night = night.plusDays(1)) {
            Month month = night.getMonth();
            if (month == Month.JUNE || month == Month.JULY || month == Month.AUGUST || month == Month.DECEMBER) {
                total += room.getPricePerNight() * 125 / 100;
            } else if (month == Month.NOVEMBER) {
                total += room.getPricePerNight() * 85 / 100;
            } else {
                total += room.getPricePerNight();
            }
        }
        return total;
    }
}
