package hotel.pricing;

import hotel.model.Room;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class StandardPricing implements PricingStrategy {

    @Override
    public String getName() {
        return "Standard (price x nights)";
    }

    @Override
    public long calculatePrice(Room room, LocalDate checkIn, LocalDate checkOut) {
        long nights = ChronoUnit.DAYS.between(checkIn, checkOut);
        return room.getPricePerNight() * nights;
    }
}
