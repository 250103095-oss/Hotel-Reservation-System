package hotel.pricing;

import hotel.model.Room;

import java.time.LocalDate;

public interface PricingStrategy {
    String getName();

    long calculatePrice(Room room, LocalDate checkIn, LocalDate checkOut);
}
