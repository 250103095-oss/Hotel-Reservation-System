package hotel.pricing;

import hotel.model.Room;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class LongStayDiscount implements PricingStrategy {

    @Override
    public String getName() {
        return "Long stay (7+ nights -10%)";
    }

    @Override
    public long calculatePrice(Room room, LocalDate checkIn, LocalDate checkOut) {
        long nights = ChronoUnit.DAYS.between(checkIn, checkOut);
        long price = room.getPricePerNight() * nights;
        if (nights >= 7) {
            price = price * 90 / 100;
        }
        return price;
    }
}
