package hotel;

import hotel.payment.QuickPayAdapter;
import hotel.payment.QuickPayClient;
import hotel.pricing.LongStayDiscount;
import hotel.pricing.SeasonalPricing;
import hotel.pricing.StandardPricing;
import hotel.repository.NotificationRepository;
import hotel.repository.PaymentRepository;
import hotel.repository.ReservationRepository;
import hotel.repository.RoomRepository;
import hotel.repository.UserRepository;
import hotel.service.AuthService;
import hotel.service.NotificationService;
import hotel.service.PaymentService;
import hotel.service.PricingService;
import hotel.service.ReservationService;
import hotel.service.RoomService;
import hotel.ui.ConsoleApp;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.List;

public class Main {

    public static void main(String[] args) throws IOException {
        Path data = Path.of("data");
        boolean reset = args.length > 0 && args[0].equals("--reset");
        prepareData(data, Path.of("database", "seed"), reset);

        UserRepository userRepo = new UserRepository(data);
        RoomRepository roomRepo = new RoomRepository(data);
        ReservationRepository reservationRepo = new ReservationRepository(data);
        PaymentRepository paymentRepo = new PaymentRepository(data);
        NotificationRepository notificationRepo = new NotificationRepository(data);

        PricingService pricing = new PricingService(List.of(
                new StandardPricing(), new SeasonalPricing(), new LongStayDiscount()));
        NotificationService notifications = new NotificationService(notificationRepo);
        AuthService auth = new AuthService(userRepo);
        RoomService rooms = new RoomService(roomRepo, reservationRepo);
        ReservationService reservations = new ReservationService(reservationRepo, rooms, pricing, notifications);
        PaymentService payments = new PaymentService(new QuickPayAdapter(new QuickPayClient()),
                paymentRepo, reservations, notifications);


        new ConsoleApp(auth, rooms, reservations, payments, pricing, notifications).start();
    }

    static void prepareData(Path data, Path seed, boolean reset) throws IOException {
        Files.createDirectories(data);
        String[] files = {"users.csv", "rooms.csv", "reservations.csv", "payments.csv", "notifications.csv"};
        for (String file : files) {
            if ((reset || !Files.exists(data.resolve(file))) && Files.exists(seed.resolve(file))) {
                Files.copy(seed.resolve(file), data.resolve(file), StandardCopyOption.REPLACE_EXISTING);
            }
        }
    }
}
