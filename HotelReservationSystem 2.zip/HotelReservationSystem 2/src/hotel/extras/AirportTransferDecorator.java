package hotel.extras;

public class AirportTransferDecorator extends BookingDecorator {

    public AirportTransferDecorator(Booking booking) {
        super(booking);
    }

    @Override
    public String getDescription() {
        return super.getDescription() + " + Airport transfer";
    }

    @Override
    public long getPrice() {
        return super.getPrice() + 12_000;
    }
}
