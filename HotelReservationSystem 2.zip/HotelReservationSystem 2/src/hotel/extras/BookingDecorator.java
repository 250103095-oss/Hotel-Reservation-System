package hotel.extras;

public abstract class BookingDecorator implements Booking {
    protected final Booking booking;
    protected BookingDecorator(Booking booking) {
        this.booking = booking;
    }

    @Override
    public String getDescription() {

        return booking.getDescription();
    }

    @Override
    public long getPrice() {
        return booking.getPrice();
    }

    @Override
    public int getNights() {
        return booking.getNights();
    }
}
