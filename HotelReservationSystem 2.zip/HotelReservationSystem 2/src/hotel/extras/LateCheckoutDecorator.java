package hotel.extras;

public class LateCheckoutDecorator extends BookingDecorator {

    public LateCheckoutDecorator(Booking booking) {
        super(booking);
    }

    @Override
    public String getDescription() {
        return super.getDescription() + " + Late check-out";
    }

    @Override
    public long getPrice() {
        return super.getPrice() + 8_000;
    }
}
