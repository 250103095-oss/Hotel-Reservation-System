package hotel.extras;

public interface Booking {
    String getDescription();
    long getPrice();
    int getNights();
}
