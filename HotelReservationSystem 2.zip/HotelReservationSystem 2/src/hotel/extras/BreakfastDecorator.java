package hotel.extras;

public class BreakfastDecorator extends BookingDecorator {

    public BreakfastDecorator(Booking booking) {
        super(booking);
    }

    @Override
    public String getDescription() {
        return super.getDescription() + " + Breakfast";
    }

    @Override
    public long getPrice() {
        return super.getPrice() + 5_000L * getNights();
    }
}
