package hotel.extras;

public class BasicBooking implements Booking {
    private final String roomNumber;
    private final int nights;
    private final long roomPrice;

    public BasicBooking(String roomNumber, int nights, long roomPrice) {
        this.roomNumber = roomNumber;
        this.nights = nights;
        this.roomPrice = roomPrice;
    }

    @Override
    public String getDescription() {
        return "Room " + roomNumber + ", " + nights + " night(s)";
    }

    @Override
    public long getPrice() {
        return roomPrice;
    }

    @Override
    public int getNights() {
        return nights;
    }
}
