package hotel.repository;

import hotel.model.Reservation;
import hotel.model.ReservationStatus;

import java.nio.file.Path;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class ReservationRepository extends FileRepository<Reservation> {

    public ReservationRepository(Path dataFolder) {
        super(dataFolder, "reservations.csv",
                "id;customer_id;room_number;check_in;check_out;guests;extras;total_price;description;status");
    }

    public List<Reservation> findByCustomer(int customerId) {
        List<Reservation> result = new ArrayList<>();
        for (Reservation r : findAll()) {
            if (r.getCustomerId() == customerId) {
                result.add(r);
            }
        }
        return result;
    }

    public List<Reservation> findByRoom(String roomNumber) {
        List<Reservation> result = new ArrayList<>();
        for (Reservation r : findAll()) {
            if (r.getRoomNumber().equals(roomNumber)) {
                result.add(r);
            }
        }
        return result;
    }

    @Override
    protected Reservation fromRow(String[] r) {
        return new Reservation(Integer.parseInt(r[0]), Integer.parseInt(r[1]), r[2], LocalDate.parse(r[3]),
                LocalDate.parse(r[4]), Integer.parseInt(r[5]), r[6], Long.parseLong(r[7]), r[8],
                ReservationStatus.valueOf(r[9]));
    }

    @Override
    protected String[] toRow(Reservation r) {
        return new String[]{String.valueOf(r.getId()), String.valueOf(r.getCustomerId()), r.getRoomNumber(),
                r.getCheckIn().toString(), r.getCheckOut().toString(), String.valueOf(r.getGuests()), r.getExtras(),
                String.valueOf(r.getTotalPrice()), r.getDescription(), r.getStatus().name()};
    }

    @Override
    protected int getId(Reservation r) { return r.getId(); }

    @Override
    protected void setId(Reservation r, int id) { r.setId(id); }
}
