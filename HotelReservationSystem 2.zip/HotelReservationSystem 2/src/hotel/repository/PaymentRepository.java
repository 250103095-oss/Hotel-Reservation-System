package hotel.repository;

import hotel.model.Payment;

import java.nio.file.Path;
import java.time.LocalDateTime;

public class PaymentRepository extends FileRepository<Payment> {

    public PaymentRepository(Path dataFolder) {
        super(dataFolder, "payments.csv", "id;reservation_id;amount;successful;transaction_id;message;date");
    }

    @Override
    protected Payment fromRow(String[] r) {
        return new Payment(Integer.parseInt(r[0]), Integer.parseInt(r[1]), Long.parseLong(r[2]),
                Boolean.parseBoolean(r[3]), r[4], r[5], LocalDateTime.parse(r[6]));
    }

    @Override
    protected String[] toRow(Payment p) {
        return new String[]{String.valueOf(p.getId()), String.valueOf(p.getReservationId()),
                String.valueOf(p.getAmount()), String.valueOf(p.isSuccessful()), p.getTransactionId(),
                p.getMessage(), p.getDate().toString()};
    }

    @Override
    protected int getId(Payment p) { return p.getId(); }

    @Override
    protected void setId(Payment p, int id) { p.setId(id); }
}
