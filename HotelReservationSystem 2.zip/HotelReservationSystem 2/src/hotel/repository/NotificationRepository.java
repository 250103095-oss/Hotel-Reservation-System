package hotel.repository;

import hotel.model.Notification;

import java.nio.file.Path;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class NotificationRepository extends FileRepository<Notification> {

    public NotificationRepository(Path dataFolder) {
        super(dataFolder, "notifications.csv", "id;user_id;message;date");
    }

    public List<Notification> findByUser(int userId) {
        List<Notification> result = new ArrayList<>();
        for (Notification n : findAll()) {
            if (n.getUserId() == userId) {
                result.add(n);
            }
        }
        return result;
    }

    @Override
    protected Notification fromRow(String[] r) {
        return new Notification(Integer.parseInt(r[0]), Integer.parseInt(r[1]), r[2], LocalDateTime.parse(r[3]));
    }

    @Override
    protected String[] toRow(Notification n) {
        return new String[]{String.valueOf(n.getId()), String.valueOf(n.getUserId()), n.getMessage(),
                n.getDate().toString()};
    }

    @Override
    protected int getId(Notification n) { return n.getId(); }

    @Override
    protected void setId(Notification n, int id) { n.setId(id); }
}
