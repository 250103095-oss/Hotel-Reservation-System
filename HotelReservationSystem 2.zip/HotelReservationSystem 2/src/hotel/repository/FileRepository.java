package hotel.repository;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public abstract class FileRepository<T> {
    private final CsvFile file;

    protected FileRepository(Path dataFolder, String fileName, String header) {
        this.file = new CsvFile(dataFolder.resolve(fileName), header);
    }

    protected abstract T fromRow(String[] row);

    protected abstract String[] toRow(T item);

    protected abstract int getId(T item);

    protected abstract void setId(T item, int id);

    public List<T> findAll() {
        List<T> items = new ArrayList<>();
        for (String[] row : file.readRows()) {
            items.add(fromRow(row));
        }
        return items;
    }

    public T findById(int id) {
        for (T item : findAll()) {
            if (getId(item) == id) {
                return item;
            }
        }
        return null;
    }

    /** Adds a new item (id 0 gets the next free id) or replaces the item with the same id. */
    public T save(T item) {
        List<T> items = findAll();
        if (getId(item) == 0) {
            int maxId = 0;
            for (T existing : items) {
                maxId = Math.max(maxId, getId(existing));
            }
            setId(item, maxId + 1);
            items.add(item);
        } else {
            items.removeIf(existing -> getId(existing) == getId(item));
            items.add(item);
            items.sort((a, b) -> Integer.compare(getId(a), getId(b)));
        }
        List<String[]> rows = new ArrayList<>();
        for (T i : items) {
            rows.add(toRow(i));
        }
        file.writeRows(rows);
        return item;
    }
}
