package hotel.repository;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public class CsvFile {
    private static final String SEPARATOR = ";";
    private final Path path;
    private final String header;

    public CsvFile(Path path, String header) {
        this.path = path;
        this.header = header;
    }

    public List<String[]> readRows() {
        List<String[]> rows = new ArrayList<>();
        if (!Files.exists(path)) {
            return rows;
        }
        try {
            List<String> lines = Files.readAllLines(path, StandardCharsets.UTF_8);
            for (int i = 1; i < lines.size(); i++) {          // line 0 is the header
                if (!lines.get(i).isBlank()) {
                    rows.add(lines.get(i).split(SEPARATOR, -1));
                }
            }
            return rows;
        } catch (IOException e) {
            throw new UncheckedIOException("Cannot read " + path, e);
        }
    }

    public void writeRows(List<String[]> rows) {
        List<String> lines = new ArrayList<>();
        lines.add(header);
        for (String[] row : rows) {
            String[] clean = new String[row.length];
            for (int i = 0; i < row.length; i++) {
                clean[i] = row[i] == null ? "" : row[i].replace(SEPARATOR, ",").replace("\n", " ");
            }
            lines.add(String.join(SEPARATOR, clean));
        }
        try {
            Files.createDirectories(path.toAbsolutePath().getParent());
            Files.write(path, lines, StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new UncheckedIOException("Cannot write " + path, e);
        }
    }
}
