package hotel.repository;

import hotel.model.Role;
import hotel.model.User;

import java.nio.file.Path;

public class UserRepository extends FileRepository<User> {

    public UserRepository(Path dataFolder) {
        super(dataFolder, "users.csv", "id;username;password_hash;full_name;phone;role");
    }

    public User findByUsername(String username) {
        for (User user : findAll()) {
            if (user.getUsername().equalsIgnoreCase(username)) {
                return user;
            }
        }
        return null;
    }

    @Override
    protected User fromRow(String[] r) {
        return new User(Integer.parseInt(r[0]), r[1], r[2], r[3], r[4], Role.valueOf(r[5]));
    }

    @Override
    protected String[] toRow(User u) {
        return new String[]{String.valueOf(u.getId()), u.getUsername(), u.getPasswordHash(), u.getFullName(),
                u.getPhone(), u.getRole().name()};
    }

    @Override
    protected int getId(User u) { return u.getId(); }

    @Override
    protected void setId(User u, int id) { u.setId(id); }
}
