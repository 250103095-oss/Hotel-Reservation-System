package hotel.repository;

import hotel.model.Room;
import hotel.model.RoomType;

import java.nio.file.Path;

public class RoomRepository extends FileRepository<Room> {

    public RoomRepository(Path dataFolder) {
        super(dataFolder, "rooms.csv", "id;number;type;capacity;price_per_night");
    }

    public Room findByNumber(String number) {
        for (Room room : findAll()) {
            if (room.getNumber().equals(number)) {
                return room;
            }
        }
        return null;
    }

    @Override
    protected Room fromRow(String[] r) {
        return new Room(Integer.parseInt(r[0]), r[1], RoomType.valueOf(r[2]), Integer.parseInt(r[3]), Long.parseLong(r[4]));
    }

    @Override
    protected String[] toRow(Room r) {
        return new String[]{String.valueOf(r.getId()), r.getNumber(), r.getType().name(),
                String.valueOf(r.getCapacity()), String.valueOf(r.getPricePerNight())};
    }

    @Override
    protected int getId(Room r) { return r.getId(); }

    @Override
    protected void setId(Room r, int id) { r.setId(id); }
}
