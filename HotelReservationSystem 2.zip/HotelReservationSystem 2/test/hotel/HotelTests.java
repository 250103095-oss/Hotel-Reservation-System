package hotel;

import hotel.exception.HotelException;
import hotel.exception.PaymentException;
import hotel.exception.ValidationException;
import hotel.extras.AirportTransferDecorator;
import hotel.extras.BasicBooking;
import hotel.extras.Booking;
import hotel.extras.BreakfastDecorator;
import hotel.extras.LateCheckoutDecorator;
import hotel.model.Reservation;
import hotel.model.ReservationStatus;
import hotel.model.Role;
import hotel.model.Room;
import hotel.model.RoomType;
import hotel.model.User;
import hotel.payment.PaymentResult;
import hotel.payment.QuickPayAdapter;
import hotel.payment.QuickPayClient;
import hotel.pricing.LongStayDiscount;
import hotel.pricing.PricingStrategy;
import hotel.pricing.SeasonalPricing;
import hotel.pricing.StandardPricing;
import hotel.repository.NotificationRepository;
import hotel.repository.PaymentRepository;
import hotel.repository.ReservationRepository;
import hotel.repository.RoomRepository;
import hotel.repository.UserRepository;
import hotel.service.AuthService;
import hotel.service.NotificationService;
import hotel.service.PaymentService;
import hotel.service.PricingService;
import hotel.service.ReservationService;
import hotel.service.RoomService;

import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.util.List;

/**
 * Automated tests. Run: ./test.sh (or test.bat).
 * Every test gets a new empty data folder, so tests do not touch the real data.
 */
public class HotelTests {
    private static int passed = 0;
    private static int failed = 0;

    // objects of one test
    private Path folder;
    private AuthService auth;
    private RoomService rooms;
    private PricingService pricing;
    private ReservationService reservations;
    private PaymentService payments;
    private User aida;
    private User bagdat;
    private final LocalDate in10 = LocalDate.now().plusDays(10);   // a date 10 days from today

    public static void main(String[] args) {
        System.out.println("--- Main functionality ---");
        run("T1 Register and log in", HotelTests::registerAndLogin);
        run("T2 Create reservation (price and status)", HotelTests::createReservation);
        run("T3 Double booking is not allowed", HotelTests::doubleBooking);
        run("T4 Pay for reservation -> CONFIRMED", HotelTests::payReservation);
        run("T5 Cancel reservation -> room is free again", HotelTests::cancelReservation);
        run("T6 Check in and check out", HotelTests::checkInOut);
        run("T7 Data is saved in files (restart)", HotelTests::persistence);
        System.out.println("--- Strategy pattern ---");
        run("S1 Three strategies give different prices", HotelTests::strategiesPrices);
        run("S2 Strategy changed at runtime, new strategy needs no code changes", HotelTests::strategySwitch);
        System.out.println("--- Decorator pattern ---");
        run("D1 Three decorators combined", HotelTests::decoratorsCombined);
        run("D2 Original booking is not changed", HotelTests::decoratorOriginal);
        System.out.println("--- Adapter pattern ---");
        run("A1 Adapter converts KZT to tiyn and returns transaction id", HotelTests::adapterApproved);
        run("A2 Adapter turns error codes into messages", HotelTests::adapterDeclined);
        System.out.println("--- Invalid input / errors ---");
        run("E1 Wrong dates are rejected", HotelTests::wrongDates);
        run("E2 Wrong password and bad registration data", HotelTests::wrongLogin);
        run("E3 Too many guests and unknown room", HotelTests::wrongRoom);

        System.out.println("\n===== " + (passed + failed) + " tests: " + passed + " passed, " + failed + " failed =====");
        if (failed > 0) {
            System.exit(1);
        }
    }

    // ===================== main functionality =====================

    static void registerAndLogin(HotelTests t) {
        User u = t.auth.register("dana", "secret1", "Dana K", "+77017778899");
        check(u.getRole() == Role.CUSTOMER, "new user is a customer");
        check(!u.getPasswordHash().equals("secret1"), "password is not saved as plain text");
        check(t.auth.login("dana", "secret1").getId() == u.getId(), "login works");
    }

    static void createReservation(HotelTests t) {
        Reservation r = t.reservations.create(t.aida, "201", t.in10, t.in10.plusDays(3), 2, List.of("BREAKFAST"));
        check(r.getStatus() == ReservationStatus.PENDING_PAYMENT, "status PENDING_PAYMENT");
        check(r.getTotalPrice() == 3 * 40_000 + 3 * 5_000, "price 135000, was " + r.getTotalPrice());
    }

    static void doubleBooking(HotelTests t) {
        t.reservations.create(t.aida, "201", t.in10, t.in10.plusDays(3), 2, List.of());
        expectError(HotelException.class,
                () -> t.reservations.create(t.bagdat, "201", t.in10.plusDays(2), t.in10.plusDays(5), 2, List.of()));
        // starting on the check-out day of the first guest is fine
        t.reservations.create(t.bagdat, "201", t.in10.plusDays(3), t.in10.plusDays(5), 2, List.of());
    }

    static void payReservation(HotelTests t) {
        Reservation r = t.reservations.create(t.aida, "101", t.in10, t.in10.plusDays(2), 1, List.of());
        t.payments.pay(t.aida, r.getId(), "4242 4242 4242 4242", "12/30", "123");
        check(t.reservations.get(r.getId()).getStatus() == ReservationStatus.CONFIRMED, "status CONFIRMED");
        check(t.payments.getAll().size() == 1 && t.payments.getAll().get(0).isSuccessful(), "payment saved");
    }

    static void cancelReservation(HotelTests t) {
        Reservation r = t.reservations.create(t.aida, "201", t.in10, t.in10.plusDays(2), 2, List.of());
        expectError(HotelException.class, () -> t.reservations.cancel(t.bagdat, r.getId())); // not his reservation
        t.reservations.cancel(t.aida, r.getId());
        check(t.reservations.get(r.getId()).getStatus() == ReservationStatus.CANCELLED, "status CANCELLED");
        check(t.rooms.isFree("201", t.in10, t.in10.plusDays(2)), "room is free again");
    }

    static void checkInOut(HotelTests t) {
        LocalDate today = LocalDate.now();
        Reservation r = t.reservations.create(t.aida, "301", today, today.plusDays(2), 3, List.of());
        expectError(HotelException.class, () -> t.reservations.checkIn(r.getId()));   // not paid yet
        t.payments.pay(t.aida, r.getId(), "4242424242424242", "12/30", "123");
        t.reservations.checkIn(r.getId());
        check(t.reservations.get(r.getId()).getStatus() == ReservationStatus.CHECKED_IN, "CHECKED_IN");
        t.reservations.checkOut(r.getId());
        check(t.reservations.get(r.getId()).getStatus() == ReservationStatus.CHECKED_OUT, "CHECKED_OUT");
    }

    static void persistence(HotelTests t) {
        Reservation r = t.reservations.create(t.aida, "201", t.in10, t.in10.plusDays(2), 2,
                List.of("TRANSFER", "LATE_CHECKOUT"));
        // new repository objects read the same files, like after restarting the program
        Reservation loaded = new ReservationRepository(t.folder).findById(r.getId());
        check(loaded != null && loaded.getTotalPrice() == r.getTotalPrice(), "reservation read back from file");
        check(loaded.getDescription().equals("Room 201, 2 night(s) + Airport transfer + Late check-out"), "description");
        check(new UserRepository(t.folder).findByUsername("aida") != null, "user read back from file");
    }

    // ===================== Strategy =====================

    static void strategiesPrices(HotelTests t) {
        Room room = new Room(1, "201", RoomType.DELUXE, 2, 40_000);
        LocalDate in = LocalDate.of(2026, 11, 29);
        LocalDate out = LocalDate.of(2026, 12, 2);            // 2 nights in November + 1 night in December
        check(new StandardPricing().calculatePrice(room, in, out) == 120_000, "standard 3 x 40000");
        check(new SeasonalPricing().calculatePrice(room, in, out) == 34_000 + 34_000 + 50_000, "seasonal 118000");
        check(new LongStayDiscount().calculatePrice(room, in, out) == 120_000, "long stay: 3 nights no discount");
        check(new LongStayDiscount().calculatePrice(room, in, in.plusDays(7)) == 252_000, "long stay: 7 nights -10%");
    }

    static void strategySwitch(HotelTests t) {
        Reservation first = t.reservations.create(t.aida, "201", t.in10, t.in10.plusDays(7), 2, List.of());
        // a NEW strategy written here, without changing ReservationService or PricingService
        PricingStrategy flat = new PricingStrategy() {
            public String getName() { return "Flat 10000"; }
            public long calculatePrice(Room room, LocalDate in, LocalDate out) {
                return 10_000L * (out.toEpochDay() - in.toEpochDay());
            }
        };
        t.pricing.setCurrent(flat);
        Reservation second = t.reservations.create(t.bagdat, "101", t.in10, t.in10.plusDays(7), 2, List.of());
        check(first.getTotalPrice() == 280_000, "standard price 7 x 40000");
        check(second.getTotalPrice() == 70_000, "new strategy used: 7 x 10000");
    }

    // ===================== Decorator =====================

    static void decoratorsCombined(HotelTests t) {
        Booking booking = new LateCheckoutDecorator(new AirportTransferDecorator(
                new BreakfastDecorator(new BasicBooking("201", 3, 120_000))));
        check(booking.getPrice() == 120_000 + 15_000 + 12_000 + 8_000, "price 155000, was " + booking.getPrice());
        check(booking.getDescription().equals("Room 201, 3 night(s) + Breakfast + Airport transfer + Late check-out"),
                "description");
    }

    static void decoratorOriginal(HotelTests t) {
        Booking basic = new BasicBooking("101", 2, 50_000);
        Booking withBreakfast = new BreakfastDecorator(basic);
        check(withBreakfast.getPrice() == 60_000, "with breakfast 60000");
        check(basic.getPrice() == 50_000 && basic.getDescription().equals("Room 101, 2 night(s)"), "original unchanged");
    }

    // ===================== Adapter =====================

    static void adapterApproved(HotelTests t) {
        long[] sentTiyn = new long[1];
        // subclass only to see what the adapter sends; QuickPayClient itself is not changed
        QuickPayClient spy = new QuickPayClient() {
            @Override
            public int makePayment(String card, int month, int year, String cvv, long amountInTiyn) {
                sentTiyn[0] = amountInTiyn;
                return super.makePayment(card, month, year, cvv, amountInTiyn);
            }
        };
        PaymentResult result = new QuickPayAdapter(spy).pay(1_500, "4242 4242 4242 4242", "12/30", "123");
        check(result.isSuccessful(), "approved");
        check(sentTiyn[0] == 150_000, "1500 KZT sent as 150000 tiyn");
        check(result.getTransactionId().startsWith("QP-"), "transaction id from QuickPay");
    }

    static void adapterDeclined(HotelTests t) {
        QuickPayAdapter adapter = new QuickPayAdapter(new QuickPayClient());
        check(adapter.pay(1000, "4000000000000002", "12/30", "123").getMessage().equals("Insufficient funds on the card."), "51");
        check(adapter.pay(1000, "4242424242424242", "01/20", "123").getMessage().equals("The card has expired."), "54");
        check(adapter.pay(1000, "1234", "12/30", "123").getMessage().equals("Card details are invalid."), "14");
        check(!adapter.pay(1000, "4242424242424242", "2030-12", "123").isSuccessful(), "bad expiry format");
        Reservation r = t.reservations.create(t.aida, "101", t.in10, t.in10.plusDays(1), 1, List.of());
        expectError(PaymentException.class, () -> t.payments.pay(t.aida, r.getId(), "4000000000000002", "12/30", "123"));
        check(t.reservations.get(r.getId()).getStatus() == ReservationStatus.PENDING_PAYMENT, "still not paid");
    }

    // ===================== invalid input =====================

    static void wrongDates(HotelTests t) {
        expectError(ValidationException.class, () -> t.reservations.create(t.aida, "101", t.in10, t.in10, 1, List.of()));
        expectError(ValidationException.class,
                () -> t.reservations.create(t.aida, "101", t.in10.plusDays(3), t.in10, 1, List.of()));
        expectError(ValidationException.class, () -> t.reservations.create(t.aida, "101",
                LocalDate.now().minusDays(5), LocalDate.now().minusDays(3), 1, List.of()));
    }

    static void wrongLogin(HotelTests t) {
        expectError(HotelException.class, () -> t.auth.login("aida", "wrong-password"));
        expectError(ValidationException.class, () -> t.auth.register("aida", "secret1", "Copy", "+77011112233"));
        expectError(ValidationException.class, () -> t.auth.register("newuser", "123", "Name", "+77011112233"));
        expectError(ValidationException.class, () -> t.auth.register("newuser", "secret1", "Name", "12345"));
    }

    static void wrongRoom(HotelTests t) {
        expectError(ValidationException.class,
                () -> t.reservations.create(t.aida, "101", t.in10, t.in10.plusDays(1), 3, List.of()));
        expectError(HotelException.class,
                () -> t.reservations.create(t.aida, "999", t.in10, t.in10.plusDays(1), 1, List.of()));
        expectError(ValidationException.class, () -> t.rooms.addRoom("12", RoomType.STANDARD, 2, 25_000));
    }

    // ===================== tiny test framework =====================

    interface TestCase {
        void run(HotelTests t) throws Exception;
    }

    private static void run(String name, TestCase test) {
        try {
            test.run(new HotelTests());
            passed++;
            System.out.println("  PASS  " + name);
        } catch (Throwable e) {
            failed++;
            System.out.println("  FAIL  " + name + "  ->  " + e.getMessage());
        }
    }

    private static void check(boolean condition, String what) {
        if (!condition) {
            throw new AssertionError("check failed: " + what);
        }
    }

    private static void expectError(Class<? extends Exception> type, Runnable code) {
        try {
            code.run();
        } catch (Exception e) {
            if (type.isInstance(e)) {
                return;
            }
            throw new AssertionError("expected " + type.getSimpleName() + " but got " + e);
        }
        throw new AssertionError("expected " + type.getSimpleName() + " but there was no error");
    }

    /** Builds the whole application on a new empty folder with 3 rooms and 2 customers. */
    private HotelTests() {
        try {
            folder = Files.createTempDirectory("hotel-test");
            folder.toFile().deleteOnExit();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        ReservationRepository reservationRepo = new ReservationRepository(folder);
        NotificationService notifications = new NotificationService(new NotificationRepository(folder));
        auth = new AuthService(new UserRepository(folder));
        rooms = new RoomService(new RoomRepository(folder), reservationRepo);
        pricing = new PricingService(List.of(new StandardPricing(), new SeasonalPricing(), new LongStayDiscount()));
        reservations = new ReservationService(reservationRepo, rooms, pricing, notifications);
        payments = new PaymentService(new QuickPayAdapter(new QuickPayClient()), new PaymentRepository(folder),
                reservations, notifications);
        aida = auth.register("aida", "aida123", "Aida Akmurat", "+77011112233");
        bagdat = auth.register("bagdat", "bagdat123", "Bagdat Atabek", "+77014445566");
        rooms.addRoom("101", RoomType.STANDARD, 2, 25_000);
        rooms.addRoom("201", RoomType.DELUXE, 2, 40_000);
        rooms.addRoom("301", RoomType.FAMILY, 4, 50_000);
    }
}
