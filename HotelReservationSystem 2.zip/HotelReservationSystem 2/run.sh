#!/bin/sh
# Compiles and starts the program. Use ./run.sh --reset to restore the sample data.
cd "$(dirname "$0")"
mkdir -p out
javac --release 17 -d out $(find src -name "*.java") || exit 1
java -cp out hotel.Main "$@"
