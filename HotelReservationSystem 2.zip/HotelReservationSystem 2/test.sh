#!/bin/sh
# Compiles the program and the tests, then runs all tests.
cd "$(dirname "$0")"
mkdir -p out
javac --release 17 -d out $(find src test -name "*.java") || exit 1
java -cp out hotel.HotelTests
