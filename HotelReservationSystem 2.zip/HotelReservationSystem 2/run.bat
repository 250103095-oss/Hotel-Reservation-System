@echo off
rem Compiles and starts the program. Use run.bat --reset to restore the sample data.
cd /d "%~dp0"
if not exist out mkdir out
dir /s /b src\*.java > out\sources.txt
javac --release 17 -d out @out\sources.txt
if errorlevel 1 exit /b 1
java -cp out hotel.Main %*
