@echo off
rem Compiles the program and the tests, then runs all tests.
cd /d "%~dp0"
if not exist out mkdir out
dir /s /b src\*.java test\*.java > out\sources.txt
javac --release 17 -d out @out\sources.txt
if errorlevel 1 exit /b 1
java -cp out hotel.HotelTests
